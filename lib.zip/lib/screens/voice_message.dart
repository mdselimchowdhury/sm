import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';

class VoiceMessageService {
  final _storage = FirebaseStorage.instance;
  final _firestore = FirebaseFirestore.instance;

  Future<void> sendVoiceMessage(String chatId, String filePath) async {
    final ref = _storage.ref('voice_messages/$chatId/${DateTime.now().millisecondsSinceEpoch}.m4a');
    await ref.putFile(File(filePath));
    final url = await ref.getDownloadURL();

    await _firestore.collection('chats').doc(chatId).collection('messages').add({
      'type': 'voice',
      'url': url,
      'sender': FirebaseAuth.instance.currentUser!.uid,
      'timestamp': FieldValue.serverTimestamp(),
    });
  }
}