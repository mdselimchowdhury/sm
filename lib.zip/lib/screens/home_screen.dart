// home_screen.dart (নতুন ফাইল তৈরি করুন)
import 'package:flutter/material.dart';

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('হোম পেজ')),
      body: Center(child: Text('লগইন সফল!')),
    );
  }
}