import 'dart:async';
import 'dart:io';
import 'package:audioplayers/audioplayers.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:path_provider/path_provider.dart';
import 'package:record/record.dart';

class VoiceMessageService {
  final FirebaseStorage _storage = FirebaseStorage.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final AudioRecorder _recorder = AudioRecorder();
  final AudioPlayer _audioPlayer = AudioPlayer();

  // State management
  final StreamController<bool> _isRecordingController = StreamController<bool>.broadcast();
  final StreamController<int> _recordingTimerController = StreamController<int>.broadcast();
  final StreamController<double> _recordingAmplitudeController = StreamController<double>.broadcast();

  Timer? _recordingTimer;
  int _recordingDuration = 0;
  String? _currentRecordingPath;
  bool _isAmplitudeListening = false;

  // Stream getters
  Stream<bool> get isRecording => _isRecordingController.stream;
  Stream<int> get recordingTimer => _recordingTimerController.stream;
  Stream<double> get recordingAmplitude => _recordingAmplitudeController.stream;

  Future<void> sendVoiceMessage(String groupId) async {
    try {
      if (_currentRecordingPath == null) {
        throw Exception('No recording available to send');
      }

      // 1. Stop recording if active
      await stopRecording();

      // 2. Upload file
      final downloadUrl = await _uploadVoiceMessage(_currentRecordingPath!);

      // 3. Calculate duration
      final duration = await _getAudioDuration(_currentRecordingPath!);

      // 4. Save message to Firestore
      await _saveMessageToFirestore(groupId, downloadUrl, duration);

    } catch (e) {
      print('Error sending voice message: $e');
      rethrow;
    } finally {
      _cleanupRecording();
    }
  }

  Future<void> startRecording() async {
    try {
      if (await _recorder.isRecording()) {
        throw Exception('Already recording');
      }

      if (!await _recorder.hasPermission()) {
        throw Exception('Microphone permission required');
      }

      // Generate path
      final directory = await getTemporaryDirectory();
      final path = '${directory.path}/voice_${DateTime.now().millisecondsSinceEpoch}.m4a';
      _currentRecordingPath = path;

      await _recorder.start(
        const RecordConfig(
          encoder: AudioEncoder.aacLc,
          bitRate: 128000,
          sampleRate: 44100,
        ),
        path: path,
      );

      _isRecordingController.add(true);
      _startTimer();
      _startAmplitudeListener();

    } catch (e) {
      print('Error starting recording: $e');
      _currentRecordingPath = null;
      rethrow;
    }
  }

  Future<void> stopRecording() async {
    try {
      if (!await _recorder.isRecording()) return;

      await _recorder.stop();
      _stopTimer();
      _stopAmplitudeListener();
      _isRecordingController.add(false);
      _recordingAmplitudeController.add(0);
    } catch (e) {
      print('Error stopping recording: $e');
      rethrow;
    }
  }

  Future<void> cancelRecording() async {
    try {
      await stopRecording();
      if (_currentRecordingPath != null) {
        final file = File(_currentRecordingPath!);
        if (await file.exists()) {
          await file.delete();
        }
      }
      _cleanupRecording();
    } catch (e) {
      print('Error canceling recording: $e');
      rethrow;
    }
  }

  Future<int> _getAudioDuration(String filePath) async {
    try {
      await _audioPlayer.setSourceDeviceFile(filePath);
      final Duration? duration = await _audioPlayer.getDuration();
      return duration?.inMilliseconds ?? 0; // Convert Duration to milliseconds
    } catch (e) {
      print('Error calculating duration: $e');
      return 0;

  }
  }

  Future<String> _uploadVoiceMessage(String filePath) async {
    try {
      final file = File(filePath);
      final fileSize = await file.length();

      if (fileSize > 10 * 1024 * 1024) { // 10MB limit
        throw Exception('File size too large');
      }

      final ref = _storage.ref('voice_messages/${DateTime.now().millisecondsSinceEpoch}.m4a');
      await ref.putFile(file);
      return await ref.getDownloadURL();
    } catch (e) {
      print('Error uploading voice message: $e');
      rethrow;
    }
  }

  Future<void> _saveMessageToFirestore(
      String groupId,
      String downloadUrl,
      int duration,
      ) async {
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) throw Exception('User not logged in');

      await _firestore
          .collection('groups')
          .doc(groupId)
          .collection('messages')
          .add({
        'type': 'voice',
        'url': downloadUrl,
        'sender': user.uid,
        'senderName': user.displayName ?? 'Unknown',
        'duration': duration,
        'timestamp': FieldValue.serverTimestamp(),
        'status': 'sent',
        'seenBy': [],
      });
    } catch (e) {
      print('Error saving message to Firestore: $e');
      rethrow;
    }
  }

  void _startTimer() {
    _recordingDuration = 0;
    _recordingTimerController.add(0);
    _recordingTimer = Timer.periodic(Duration(seconds: 1), (timer) {
      _recordingDuration++;
      _recordingTimerController.add(_recordingDuration);
    });
  }

  void _stopTimer() {
    _recordingTimer?.cancel();
    _recordingTimer = null;
  }

  void _startAmplitudeListener() async {
    _isAmplitudeListening = true;
    while (_isAmplitudeListening && await _recorder.isRecording()) {
      try {
        final amplitude = await _recorder.getAmplitude();
        _recordingAmplitudeController.add(amplitude?.current ?? 0);
        await Future.delayed(Duration(milliseconds: 100));
      } catch (e) {
        print('Error in amplitude listener: $e');
        break;
      }
    }
  }

  void _stopAmplitudeListener() {
    _isAmplitudeListening = false;
  }

  void _cleanupRecording() {
    _stopTimer();
    _stopAmplitudeListener();
    _currentRecordingPath = null;
    _recordingDuration = 0;
  }

  Future<void> dispose() async {
    try {
      await stopRecording();
      await _recorder.dispose();
      await _audioPlayer.dispose();
      await _isRecordingController.close();
      await _recordingTimerController.close();
      await _recordingAmplitudeController.close();
    } catch (e) {
      print('Error disposing resources: $e');
    }
  }
}