import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class ReactionService {
  final _firestore = FirebaseFirestore.instance;

  // রিঅ্যাকশন যোগ/আপডেট
  Future<void> addReaction({
    required String messageId,
    required String chatId,
    required String emoji,
  }) async {
    final userId = FirebaseAuth.instance.currentUser!.uid;
    await _firestore
        .collection('chats')
        .doc(chatId)
        .collection('messages')
        .doc(messageId)
        .update({
      'reactions.$userId': emoji,
    });
  }

  // রিঅ্যাকশন মুছুন
  Future<void> removeReaction({
    required String messageId,
    required String chatId,
  }) async {
    final userId = FirebaseAuth.instance.currentUser!.uid;
    await _firestore
        .collection('chats')
        .doc(chatId)
        .collection('messages')
        .doc(messageId)
        .update({
      'reactions.$userId': FieldValue.delete(),
    });
  }
}