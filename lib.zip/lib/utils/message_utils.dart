class MessageUtils {
  static bool canRestoreMessage(Map<String, dynamic> messageData) {
    final deletedAt = messageData['deletedAt']?.toDate();
    if (deletedAt == null) return false;

    return DateTime.now().difference(deletedAt).inHours <= 24;
  }
}