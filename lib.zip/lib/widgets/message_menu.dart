import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../services/message_service.dart';

class MessageMenu extends StatelessWidget {
  final String chatId;
  final String messageId;
  final String currentText;
  final bool isMyMessage;

  const MessageMenu({
    required this.chatId,
    required this.messageId,
    required this.currentText,
    required this.isMyMessage,
  });

  void _showEditDialog(BuildContext context) {
    final _textController = TextEditingController(text: currentText);

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text("মেসেজ এডিট করুন"),
        content: TextField(controller: _textController),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("বাতিল"),
          ),
          TextButton(
            onPressed: () {
              MessageService().editMessage(
                chatId: chatId,
                messageId: messageId,
                newText: _textController.text,
              );
              Navigator.pop(context);
            },
            child: Text("সেভ করুন"),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return PopupMenuButton(
      itemBuilder: (context) => [
        if (isMyMessage)
          PopupMenuItem(
            child: Text("এডিট করুন"),
            onTap: () => _showEditDialog(context),
          ),
        if (isMyMessage)
          PopupMenuItem(
            child: Text("আনসেন্ড করুন"),
            onTap: () => MessageService().unsendMessage(
              chatId: chatId,
              messageId: messageId,
            ),
          ),
      ],
    );
  }
}