import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../services/message_restore_service.dart';

class DeletedMessageBubble extends StatefulWidget {
  final String chatId;
  final String messageId;
  final bool isMyMessage;
  final Map<String, dynamic> originalData;

  const DeletedMessageBubble({
    required this.chatId,
    required this.messageId,
    required this.isMyMessage,
    required this.originalData,
  });

  @override
  _DeletedMessageBubbleState createState() => _DeletedMessageBubbleState();
}

class _DeletedMessageBubbleState extends State<DeletedMessageBubble> with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;
  bool _showOriginal = false;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 500),
      vsync: this,
    );
    _fadeAnimation = Tween<double>(begin: 0, end: 1).animate(_animationController);
    _animationController.forward();
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: _fadeAnimation,
      child: Container(
        padding: EdgeInsets.all(12),
        margin: EdgeInsets.symmetric(vertical: 4),
        decoration: BoxDecoration(
          color: Colors.grey[200],
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "এই মেসেজটি ডিলিট করা হয়েছে",
              style: TextStyle(fontStyle: FontStyle.italic, color: Colors.grey),
            ),

            if (_showOriginal && widget.originalData['text'] != null)
              Padding(
                padding: const EdgeInsets.only(top: 8.0),
                child: Text(
                  widget.originalData['text'],
                  style: TextStyle(color: Colors.black87),
                ),
              ),

            Row(
              children: [
                TextButton(
                  onPressed: () => setState(() => _showOriginal = !_showOriginal),
                  child: Text(
                    _showOriginal ? "মেসেজ লুকান" : "মেসেজ দেখুন",
                    style: TextStyle(color: Colors.blue),
                  ),
                ),
                if (widget.isMyMessage)
                  TextButton(
                    onPressed: () => _restoreMessage(context),
                    child: Text(
                      "রিস্টোর করুন",
                      style: TextStyle(color: Colors.blue),
                    ),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void _restoreMessage(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text("মেসেজ রিস্টোর করুন"),
        content: Text("আপনি কি নিশ্চিত এই মেসেজটি ফিরে আনতে চান?"),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("না"),
          ),
          TextButton(
            onPressed: () {
              MessageRestoreService().restoreMessage(
                chatId: widget.chatId,
                messageId: widget.messageId,
              );
              Navigator.pop(context);
            },
            child: Text("হ্যাঁ"),
          ),
        ],
      ),
    );
  }
}