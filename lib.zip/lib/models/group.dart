class Group {
  final String id;
  final String name;
  final List<String> members;
  final String admin;

  Group({required this.id, required this.name, required this.members, required this.admin});
}