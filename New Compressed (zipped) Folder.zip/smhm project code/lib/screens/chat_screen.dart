import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class ChatScreen extends StatelessWidget {
  final _firestore = FirebaseFirestore.instance;
  final _auth = FirebaseAuth.instance;

  void _sendMessage(String text) {
    _firestore.collection('messages').add({
      'text': text,
      'sender': _auth.currentUser!.uid, // ইউজার আইডি সেভ করে
      'timestamp': FieldValue.serverTimestamp(),
      'status': 'active', // ডিফল্ট স্ট্যাটাস
    });
  }

  void _deleteMessage(String messageId) {
    _firestore.collection('messages').doc(messageId).update({
      'status': 'deleted',
      'originalData': _firestore.collection('messages').doc(messageId).get(), // ডিলিটের আগের ডাটা সেভ করে
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('চ্যাট')),
      body: Column(
        children: [
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: _firestore.collection('messages').orderBy('timestamp').snapshots(),
              builder: (context, snapshot) {
                if (!snapshot.hasData) return Center(child: CircularProgressIndicator());
                final messages = snapshot.data!.docs;
                return ListView.builder(
                  itemCount: messages.length,
                  itemBuilder: (context, index) {
                    final message = messages[index];
                    final data = message.data() as Map<String, dynamic>;

                    // ডিলিট মেসেজ চেক
                    if (data['status'] == 'deleted') {
                      return Padding(
                        padding: EdgeInsets.symmetric(vertical: 5, horizontal: 10),
                        child: Text(
                          'মেসেজ ডিলিট করা হয়েছে',
                          style: TextStyle(color: Colors.grey, fontStyle: FontStyle.italic),
                        ),
                      );
                    }

                    // নরমাল মেসেজ বাবল
                    return Padding(
                      padding: EdgeInsets.symmetric(vertical: 5, horizontal: 10),
                      child: Align(
                        alignment: data['sender'] == _auth.currentUser!.uid
                            ? Alignment.centerRight // আমার মেসেজ ডানদিকে
                            : Alignment.centerLeft, // অন্যদের মেসেজ বামে
                        child: Container(
                          padding: EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            color: data['sender'] == _auth.currentUser!.uid
                                ? Colors.blue[100] // আমার মেসেজের কালার
                                : Colors.grey[300], // অন্যদের মেসেজের কালার
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Text(data['text']),
                              if (data['sender'] == _auth.currentUser!.uid)
                                GestureDetector(
                                  onTap: () => _deleteMessage(message.id), // ডিলিট বাটন
                                  child: Text(
                                    'ডিলিট',
                                    style: TextStyle(color: Colors.red, fontSize: 10),
                                  ),
                                ),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ),
          Padding(
            padding: EdgeInsets.all(8),
            child: TextField(
              onSubmitted: _sendMessage,
              decoration: InputDecoration(
                hintText: 'মেসেজ লিখুন...',
                border: OutlineInputBorder(),
                suffixIcon: IconButton(
                  icon: Icon(Icons.send),
                  onPressed: () {
                    if (_textController.text.isNotEmpty) {
                      _sendMessage(_textController.text);
                      _textController.clear();
                    }
                  },
                ),
              ),
              controller: _textController,
            ),
          ),
        ],
      ),
    );
  }

  final _textController = TextEditingController(); // টেক্সট কন্ট্রোলার
}