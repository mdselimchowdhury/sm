import 'package:permission_handler/permission_handler.dart';
import 'package:record/record.dart';
import 'package:path_provider/path_provider.dart';

class VoiceRecorder {
  final AudioRecorder _audioRecorder = AudioRecorder();

  // Check and request microphone permission
  Future<bool> _checkPermissions() async {
    try {
      final status = await Permission.microphone.request();
      return status.isGranted;
    } catch (e) {
      print('Permission error: $e');
      return false;
    }
  }

  Future<String?> startRecording() async {
    // Verify permissions
    if (!await _checkPermissions()) {
      print('Microphone permission denied');
      return null;
    }

    try {
      // Create file path
      final dir = await getTemporaryDirectory();
      final path = '${dir.path}/recording_${DateTime.now().millisecondsSinceEpoch}.m4a';

      // Start recording
      await _audioRecorder.start(
        RecordConfig(
          encoder: AudioEncoder.aacLc,  // AAC format
          bitRate: 128000,             // 128 kbps
          sampleRate: 44100,           // 44.1 kHz
        ),
        path: path,  // Save location
      );

      return path;
    } catch (e) {
      print('Recording failed: $e');
      return null;
    }
  }

  Future<String?> stopRecording() async {
    try {
      return await _audioRecorder.stop();
    } catch (e) {
      print('Failed to stop recording: $e');
      return null;
    }
  }

  Future<void> dispose() async {
    await _audioRecorder.dispose();
  }
}