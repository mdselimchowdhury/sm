import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class CreateGroupScreen extends StatefulWidget {
  @override
  _CreateGroupScreenState createState() => _CreateGroupScreenState();
}

class _CreateGroupScreenState extends State<CreateGroupScreen> {
  final _firestore = FirebaseFirestore.instance;
  final _auth = FirebaseAuth.instance;
  final _groupNameController = TextEditingController();
  List<String> _selectedUsers = [];

  void _createGroup() async {
    await _firestore.collection('groups').add({
      'name': _groupNameController.text,
      'members': [..._selectedUsers, _auth.currentUser!.uid],
      'admin': _auth.currentUser!.uid,
      'createdAt': FieldValue.serverTimestamp(),
    });
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('নতুন গ্রুপ তৈরি করুন')),
      body: Column(
        children: [
          TextField(controller: _groupNameController, decoration: InputDecoration(labelText: 'গ্রুপের নাম')),
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: _firestore.collection('users').snapshots(),
              builder: (context, snapshot) {
                if (!snapshot.hasData) return CircularProgressIndicator();
                return ListView.builder(
                  itemCount: snapshot.data!.docs.length,
                  itemBuilder: (context, index) {
                    final user = snapshot.data!.docs[index];
                    return CheckboxListTile(
                      title: Text(user['email']),
                      value: _selectedUsers.contains(user.id),
                      onChanged: (value) {
                        setState(() {
                          if (value!) {
                            _selectedUsers.add(user.id);
                          } else {
                            _selectedUsers.remove(user.id);
                          }
                        });
                      },
                    );
                  },
                );
              },
            ),
          ),
          ElevatedButton(onPressed: _createGroup, child: Text('গ্রুপ তৈরি করুন')),
        ],
      ),
    );
  }
}