import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class PresenceService {
  final _firestore = FirebaseFirestore.instance;

  // ইউজার অনলাইন/অফলাইন আপডেট
  void updatePresence(bool isOnline) {
    _firestore.collection('users').doc(FirebaseAuth.instance.currentUser!.uid).update({
      'isOnline': isOnline,
      'lastSeen': FieldValue.serverTimestamp(),
    });
  }

  // প্রাইভেসি সেটিংস
  Future<void> setPrivacy({bool? hidePresence, bool? hideLastSeen}) async {
    await _firestore.collection('users').doc(FirebaseAuth.instance.currentUser!.uid).update({
      'privacy.hidePresence': hidePresence,
      'privacy.hideLastSeen': hideLastSeen,
    });
  }

  // অন্যান্য ইউজারের প্রেজেন্স ডাটা ফেচ
  Stream<DocumentSnapshot> getUserPresence(String userId) {
    return _firestore.collection('users').doc(userId).snapshots();
  }
}