import 'package:firebase_storage/firebase_storage.dart';

class BackupService {
  final _storage = FirebaseStorage.instance;

  Future<void> backupData(String userId, String data) async {
    await _storage.ref('backups/$userId.json').putString(data);
    print('ডাটা ব্যাকআপ সম্পন্ন!');
  }
}