import 'package:cloud_firestore/cloud_firestore.dart';

class MessageRestoreService {
  final _firestore = FirebaseFirestore.instance;

  // ডিলিট করা মেসেজ রিস্টোর
  Future<void> restoreMessage({
    required String chatId,
    required String messageId,
  }) async {
    final doc = await _firestore
        .collection('chats')
        .doc(chatId)
        .collection('messages')
        .doc(messageId)
        .get();

    if (doc.exists && doc.data()?['status'] == 'deleted') {
      await doc.reference.update({
        'status': 'active',
        'text': doc.data()?['originalData']['text'],
        'originalData': FieldValue.delete(),
        'deletedAt': FieldValue.delete(),
      });
    }
  }

  // সফ্ট ডিলিট (মূল ডাটা সেভ করে)
  Future<void> softDelete({
    required String chatId,
    required String messageId,
  }) async {
    final doc = await _firestore
        .collection('chats')
        .doc(chatId)
        .collection('messages')
        .doc(messageId)
        .get();

    if (doc.exists) {
      await doc.reference.update({
        'status': 'deleted',
        'originalData': {
          'text': doc.data()?['text'],
          'sender': doc.data()?['sender'],
          'timestamp': doc.data()?['timestamp'],
        },
        'text': 'এই মেসেজটি ডিলিট করা হয়েছে',
        'deletedAt': FieldValue.serverTimestamp(),
      });
    }
  }
}