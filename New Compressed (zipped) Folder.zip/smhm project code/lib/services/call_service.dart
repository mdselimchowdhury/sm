import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class CallService {
  final _firestore = FirebaseFirestore.instance;
  final _auth = FirebaseAuth.instance;

  void _sendCallSignal(String groupId, String type) {
    _firestore.collection('groups').doc(groupId).collection('calls').add({
      'caller': _auth.currentUser!.uid,
      'type': type, // 'video' or 'audio'
      'timestamp': FieldValue.serverTimestamp(),
    });
  }

  Stream<DocumentSnapshot> _getCallStream(String groupId) {
    return _firestore
        .collection('groups')
        .doc(groupId)
        .collection('calls')
        .orderBy('timestamp', descending: true)
        .limit(1)
        .snapshots()
        .map((snapshot) => snapshot.docs.first);
  }
}