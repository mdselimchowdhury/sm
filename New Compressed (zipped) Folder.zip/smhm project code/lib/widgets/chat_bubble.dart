import 'package:flutter/material.dart';
import 'package:smhm/widgets/reaction_popup.dart';

class ChatBubble extends StatelessWidget {
  final Message message;
  final bool isMe;

  const ChatBubble({
    Key? key,
    required this.message,
    required this.isMe,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onLongPress: () => _showReactionPopup(context),
      child: Container(
        padding: const EdgeInsets.all(12),
        margin: const EdgeInsets.symmetric(vertical: 4),
        decoration: BoxDecoration(
          color: isMe ? Colors.blue[100] : Colors.grey[200],
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(message.text),
            if (message.reactions != null && message.reactions!.isNotEmpty)
              _buildReactions(message.reactions!),
          ],
        ),
      ),
    );
  }

  void _showReactionPopup(BuildContext context) {
    final renderBox = context.findRenderObject() as RenderBox;
    final position = renderBox.localToGlobal(Offset.zero);

    showDialog(
      context: context,
      builder: (_) => ReactionPopup(
        messageId: message.id,
        chatId: message.chatId,
        position: position,
      ),
    );
  }

  Widget _buildReactions(Map<String, dynamic> reactions) {
    return Container(
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: reactions.entries
            .map((entry) => Text(entry.value, style: const TextStyle(fontSize: 16)))
            .toList(),
      ),
    );
  }
}

// Message class should be defined in your project
class Message {
  final String id;
  final String chatId;
  final String text;
  final Map<String, dynamic>? reactions;

  const Message({
    required this.id,
    required this.chatId,
    required this.text,
    this.reactions,
  });
}