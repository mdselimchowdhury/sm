import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'dart:async';

class VoiceButton extends StatefulWidget {
  final String groupId;
  const VoiceButton({Key? key, required this.groupId}) : super(key: key);

  @override
  _VoiceButtonState createState() => _VoiceButtonState();
}

class _VoiceButtonState extends State<VoiceButton> {
  bool _isRecording = false;
  bool _isProcessing = false;
  bool _hasPermission = false;
  Duration _recordingDuration = Duration.zero;
  Timer? _recordingTimer;
  double _audioLevel = 0.0;

  @override
  void initState() {
    super.initState();
    _checkPermission();
  }

  @override
  void dispose() {
    _recordingTimer?.cancel();
    super.dispose();
  }

  Future<void> _checkPermission() async {
    final status = await Permission.microphone.status;
    setState(() {
      _hasPermission = status.isGranted;
    });
  }

  void _startTimer() {
    _recordingTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      setState(() {
        _recordingDuration += const Duration(seconds: 1);
        // Simulate audio level changes (replace with real audio level in actual app)
        _audioLevel = 0.2 + 0.8 * (DateTime.now().second % 10) / 10;
      });
    });
  }

  void _stopTimer() {
    _recordingTimer?.cancel();
    _recordingTimer = null;
    setState(() {
      _recordingDuration = Duration.zero;
      _audioLevel = 0.0;
    });
  }

  Future<void> _toggleRecording() async {
    if (_isProcessing) return;

    if (!_hasPermission) {
      final status = await Permission.microphone.request();
      if (status.isPermanentlyDenied) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: const Text('মাইক্রোফোন অনুমতি প্রয়োজন। সেটিংস থেকে অনুমতি দিন।'),
            action: SnackBarAction(
              label: 'সেটিংস',
              onPressed: openAppSettings,
            ),
          ),
        );
        return;
      } else if (!status.isGranted) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('মাইক্রোফোন অনুমতি প্রয়োজন')),
        );
        return;
      }
      setState(() => _hasPermission = true);
    }

    setState(() => _isProcessing = true);

    try {
      if (_isRecording) {
        // Stop recording
        _stopTimer();
        debugPrint('রেকর্ডিং বন্ধ করা হয়েছে এবং গ্রুপ ${widget.groupId}-এ পাঠানো হয়েছে');
      } else {
        // Start recording
        _startTimer();
        debugPrint('রেকর্ডিং শুরু হয়েছে');
      }

      if (!mounted) return;
      setState(() {
        _isRecording = !_isRecording;
        _isProcessing = false;
      });
    } catch (e) {
      debugPrint('ত্রুটি: $e');
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('ত্রুটি: ${e.toString()}')),
      );
      setState(() => _isProcessing = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        if (_isRecording) ...[
          Text(
            '${_recordingDuration.inMinutes}:${(_recordingDuration.inSeconds % 60).toString().padLeft(2, '0')}',
            style: TextStyle(
              color: Colors.red,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 4),
          LinearProgressIndicator(
            value: _audioLevel,
            backgroundColor: Colors.grey[300],
            valueColor: AlwaysStoppedAnimation<Color>(Colors.green),
            minHeight: 2,
          ),
          const SizedBox(height: 8),
        ],
        AnimatedContainer(
          duration: const Duration(milliseconds: 300),
          decoration: BoxDecoration(
            color: _isRecording ? Colors.red.withOpacity(0.2) : Colors.transparent,
            shape: BoxShape.circle,
          ),
          child: IconButton(
            icon: _isProcessing
                ? const SizedBox(
              width: 20,
              height: 20,
              child: CircularProgressIndicator(
                strokeWidth: 2,
                valueColor: AlwaysStoppedAnimation<Color>(Colors.red),
              ),
            )
                : AnimatedSwitcher(
              duration: const Duration(milliseconds: 200),
              child: _isRecording
                  ? const Icon(Icons.stop, key: ValueKey('stop'))
                  : const Icon(Icons.mic, key: ValueKey('mic')),
            ),
            color: _isRecording ? Colors.red : Theme.of(context).primaryColor,
            splashColor: _isRecording
                ? Colors.red.withOpacity(0.5)
                : Theme.of(context).primaryColor.withOpacity(0.5),
            onPressed: _toggleRecording,
          ),
        ),
      ],
    );
  }
}