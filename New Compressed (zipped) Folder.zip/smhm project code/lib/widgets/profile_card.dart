import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../services/presence_service.dart';

class ProfileCard extends StatelessWidget {
  final String userId;
  const ProfileCard({required this.userId, Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final _presenceService = PresenceService();

    return StreamBuilder<DocumentSnapshot>(
      stream: _presenceService.getUserPresence(userId),
      builder: (context, snapshot) {
        // Handle all possible stream states
        if (snapshot.connectionState == ConnectionState.waiting) {
          return _buildLoadingTile();
        }

        if (snapshot.hasError) {
          debugPrint('Stream error: ${snapshot.error}');
          return _buildErrorTile('Failed to load data');
        }

        if (!snapshot.hasData || !snapshot.data!.exists) {
          return _buildErrorTile('User not found');
        }

        return _buildUserTile(context, snapshot.data!);
      },
    );
  }

  Widget _buildLoadingTile() {
    return const ListTile(
      leading: CircleAvatar(child: CircularProgressIndicator()),
      title: Text('Loading...'),
    );
  }

  Widget _buildErrorTile(String message) {
    return ListTile(
      leading: const CircleAvatar(child: Icon(Icons.error)),
      title: Text(message),
    );
  }

  Widget _buildUserTile(BuildContext context, DocumentSnapshot userDoc) {
    try {
      final userData = userDoc.data() as Map<String, dynamic>? ?? {};
      final privacy = (userData['privacy'] as Map<String, dynamic>?) ?? {};
      final isOnline = userData['isOnline'] as bool? ?? false;
      final name = userData['name']?.toString() ?? 'No Name';

      return ListTile(
        leading: _buildUserAvatar(name, isOnline, privacy),
        title: Text(name),
        subtitle: _buildPresenceText(context, userData, privacy),
      );
    } catch (e) {
      debugPrint('User tile build error: $e');
      return _buildErrorTile('Error displaying user info');
    }
  }

  Widget _buildUserAvatar(String name, bool isOnline, Map<String, dynamic> privacy) {
    final isHidden = privacy['hidePresence'] == true;
    final initials = name.isNotEmpty ? name[0].toUpperCase() : '?';

    return Stack(
      alignment: Alignment.center,
      children: [
        CircleAvatar(
          child: Text(initials),
        ),
        if (!isHidden && isOnline)
          Positioned(
            right: 0,
            bottom: 0,
            child: Container(
              width: 12,
              height: 12,
              decoration: BoxDecoration(
                color: Colors.green,
                shape: BoxShape.circle,
                border: Border.all(color: Colors.white, width: 2),
              ),
            ),
          ),
      ],
    );
  }

  Widget _buildPresenceText(BuildContext context, Map<String, dynamic> userData, Map<String, dynamic> privacy) {
    try {
      if (privacy['hidePresence'] == true) {
        return const Text('Presence hidden');
      }

      if (userData['isOnline'] == true) {
        return const Text('Online');
      }

      final lastSeen = userData['lastSeen'];
      if (lastSeen == null) {
        return const Text('Last seen: Unknown');
      }

      final lastSeenDate = _parseLastSeen(lastSeen);
      if (lastSeenDate == null) {
        return const Text('Last seen: Unknown');
      }

      return Text(
        'Last seen: ${_formatLastSeen(lastSeenDate)}',
        style: Theme.of(context).textTheme.bodySmall,
      );
    } catch (e) {
      debugPrint('Presence text error: $e');
      return const Text('Error showing status');
    }
  }

  DateTime? _parseLastSeen(dynamic lastSeen) {
    try {
      if (lastSeen is Timestamp) {
        return lastSeen.toDate();
      } else if (lastSeen is DateTime) {
        return lastSeen;
      } else if (lastSeen is int) {
        return DateTime.fromMillisecondsSinceEpoch(lastSeen);
      } else if (lastSeen is String) {
        return DateTime.tryParse(lastSeen);
      }
      return null;
    } catch (e) {
      debugPrint('Last seen parsing error: $e');
      return null;
    }
  }

  String _formatLastSeen(DateTime date) {
    try {
      Intl.defaultLocale = 'en_US'; // ✅ Fix: Set default locale
      return DateFormat('hh:mm a').format(date);
    } catch (e) {
      debugPrint('Date formatting error: $e');
      return 'Unknown time';
    }
  }
}
