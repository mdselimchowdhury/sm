import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../services/reaction_service.dart';

class ReactionPopup extends StatelessWidget {
  final String messageId;
  final String chatId;
  final Offset position;

  ReactionPopup({
    required this.messageId,
    required this.chatId,
    required this.position,
  });

  final List<String> _emojis = ['❤️', '😂', '😮', '😢', '👍', '👎'];

  @override
  Widget build(BuildContext context) {
    // Ensure the popup stays within screen bounds
    final double screenWidth = MediaQuery.of(context).size.width;
    final double screenHeight = MediaQuery.of(context).size.height;
    double popupLeft = position.dx;
    double popupTop = position.dy - 50;

    // Adjust if popup goes beyond right edge
    if (popupLeft + 200 > screenWidth) { // Assuming popup width is ~200
      popupLeft = screenWidth - 220;
    }

    // Adjust if popup goes beyond top edge
    if (popupTop < 0) {
      popupTop = position.dy + 30; // Show below the message instead
    }

    return Positioned(
      left: popupLeft,
      top: popupTop,
      child: Material(
        elevation: 4,
        borderRadius: BorderRadius.circular(20),
        child: Container(
          padding: EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: Colors.black12,
                blurRadius: 4,
                offset: Offset(0, 2),
              ),
            ],
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: _emojis.map((emoji) {
              return GestureDetector(
                onTap: () async {
                  try {
                    await ReactionService().addReaction(
                      messageId: messageId,
                      chatId: chatId,
                      emoji: emoji,
                    );
                    if (Navigator.canPop(context)) {
                      Navigator.pop(context);
                    }
                  } catch (e) {
                    print('Error adding reaction: $e');
                    if (Navigator.canPop(context)) {
                      Navigator.pop(context);
                    }
                  }
                },
                child: Padding(
                  padding: EdgeInsets.symmetric(horizontal: 8),
                  child: Text(emoji, style: TextStyle(fontSize: 24)),
                ),
              );
            }).toList(),
          ),
        ),
      ),
    );
  }
}